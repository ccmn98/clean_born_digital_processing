import os
import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

# collection_path = r"J:\Zbigniew Brzezinski Papers"
# collection_path = r"C:\Users\chade\OneDrive\Desktop\output"

collection_path = r"C:\Users\chade\OneDrive\Desktop\sagan"

output_xlsx = r"C:\Users\chade\OneDrive\Desktop\output\byte_count_report_4.xlsx"

wb = openpyxl.Workbook()

summary_ws = wb.active
summary_ws.title = "Summary"

dir_ws = wb.create_sheet("Directory Totals")
file_ws = wb.create_sheet("File Details")

summary_ws.append([
    "Object Name",
    "Type",
    "Path",
    "Payload Path",
    "Stored Payload Bytes",
    "Stored Payload File Count",
    "Stored Payload-Oxum",
    "Calculated Payload Bytes",
    "Calculated Payload File Count",
    "Calculated Payload-Oxum",
    "Byte Difference",
    "File Count Difference",
    "Payload-Oxum Result"
])

dir_ws.append([
    "Bag Name",
    "Directory Path",
    "Relative Directory",
    "Directory Bytes"
])

file_ws.append([
    "Bag Name",
    "File Name",
    "File Path",
    "Relative File Path",
    "File Bytes"
])

#finding directory bags
def find_bag_directories(collection_path):
    bag_paths = []

    for root, dirnames, filenames in os.walk(collection_path):
        if is_bag_directory(root):
            bag_paths.append(root)
            dirnames[:] = []

    return bag_paths
# Return TRUE if this folder looks like a BagIt bag

def is_bag_directory(path):

    return (
        os.path.isdir(os.path.join(path, "data")) and
        os.path.isfile(os.path.join(path, "bagit.txt"))
    )
    
#Walk an entire collection and decide which processing function to call.

def process_collection(collection_path):
        if is_bag_directory(collection_path):
            process_bag_directory(collection_path)
        else:
            process_regular_directory(collection_path)
            
 
def read_payload_oxum(bag_path):
    bag_info_path = os.path.join(bag_path, "bag-info.txt")

    if not os.path.isfile(bag_info_path):
        return None, None

    with open(
        bag_info_path,
        "r",
        encoding="utf-8",
        errors="replace"
    ) as bag_info:

        for line in bag_info:
            if line.lower().startswith("payload-oxum:"):
                oxum_value = line.split(":", 1)[1].strip()

                try:
                    expected_bytes_text, expected_files_text = (
                        oxum_value.split(".", 1)
                    )

                    return (
                        int(expected_bytes_text),
                        int(expected_files_text)
                    )

                except ValueError:
                    print(
                        f"Invalid Payload-Oxum in: "
                        f"{bag_info_path}"
                    )
                    return None, None

    return None, None


#Counting bytes/files inside bag_path\data and read Payload_Oxum
def process_bag_directory(bag_path):
    bag_name = os.path.basename(bag_path)
    payload_path = os.path.join(bag_path, "data")

    print(f"Processing bag directory: {bag_path}")

    expected_bytes, expected_files = read_payload_oxum(bag_path)

    total_size = 0
    file_count = 0
    directory_sizes = {}

    for data_root, data_dirs, data_files in os.walk(
        payload_path,
        topdown=False,
        onerror=walk_error
    ):
        directory_total = 0

        for filename in data_files:
            fp = os.path.join(data_root, filename)

            if os.path.islink(fp):
                continue

            try:
                size = os.path.getsize(fp)
            except OSError as error:
                print(f"Could not read file: {fp}")
                print(f"Error: {error}")
                continue

            total_size += size
            file_count += 1
            directory_total += size

            relative_file_path = os.path.relpath(fp, payload_path)

            file_ws.append([
                bag_name,
                filename,
                fp,
                relative_file_path,
                size
            ])

        for dirname in data_dirs:
            subdir = os.path.join(data_root, dirname)
            directory_total += directory_sizes.get(subdir, 0)

        directory_sizes[data_root] = directory_total

    for directory, size in sorted(directory_sizes.items()):
        relative_directory = os.path.relpath(
            directory,
            payload_path
        )

        dir_ws.append([
            bag_name,
            directory,
            relative_directory,
            size
        ])

    calculated_oxum = f"{total_size}.{file_count}"

    if expected_bytes is None or expected_files is None:
        stored_oxum = ""
        byte_difference = None
        file_difference = None
        comparison_result = "Payload-Oxum unavailable"

    else:
        stored_oxum = f"{expected_bytes}.{expected_files}"
        byte_difference = total_size - expected_bytes
        file_difference = file_count - expected_files

        if byte_difference == 0 and file_difference == 0:
            comparison_result = "MATCH"
        elif byte_difference != 0 and file_difference != 0:
            comparison_result = "BYTE AND FILE COUNT MISMATCH"
        elif byte_difference != 0:
            comparison_result = "BYTE COUNT MISMATCH"
        else:
            comparison_result = "FILE COUNT MISMATCH"

    summary_ws.append([
        bag_name,
        "BagIt Bag",
        bag_path,
        payload_path,
        expected_bytes,
        expected_files,
        stored_oxum,
        total_size,
        file_count,
        calculated_oxum,
        byte_difference,
        file_difference,
        comparison_result
    ])

    print(f"Stored Payload-Oxum: {stored_oxum or 'Unavailable'}")
    print(f"Calculated Payload-Oxum: {calculated_oxum}")
    print(f"Comparison: {comparison_result}")

    if byte_difference is not None:
        print(f"Byte difference: {byte_difference:,}")

    if file_difference is not None:
        print(f"File-count difference: {file_difference:,}")
def walk_error(error):
    print(f"os.walk error: {error}")
   
# Counting bytes/files inside a regular directory (not a BagIt bag)    
def process_regular_directory(dir_path):
    print(f"Processing regular directory: {dir_path}")

    print(f"Path exists: {os.path.exists(dir_path)}")
    print(f"Is directory: {os.path.isdir(dir_path)}")
    print(f"Can read directory: {os.access(dir_path, os.R_OK)}")

    bag_paths = find_bag_directories(dir_path)

    print(f"Bag paths found: {bag_paths}")
    


    non_bag_total_size = 0
    non_bag_file_count = 0
    non_bag_directory_sizes = {}

    for non_bag_root, non_bag_dirs, non_bag_files in os.walk(
        dir_path,
        topdown=False,
        onerror=walk_error
    ):
        print(f"Walking: {non_bag_root}")
        print(f"    Directories: {len(non_bag_dirs)}")
        print(f"    Files: {len(non_bag_files)}")

        # Skip BagIt bags and anything inside them
        if any(
            os.path.commonpath([non_bag_root, bag_path]) == bag_path
            for bag_path in bag_paths
        ):
            continue

        non_bag_directory_total = 0

        for filename in non_bag_files:
            fp = os.path.join(non_bag_root, filename)

            if os.path.islink(fp):
                continue

            size = os.path.getsize(fp)

            non_bag_total_size += size
            non_bag_file_count += 1
            non_bag_directory_total += size

            relative_file_path = os.path.relpath(fp, dir_path)

            file_ws.append([
                os.path.basename(dir_path),
                filename,
                fp,
                relative_file_path,
                size
            ])

        for dirname in non_bag_dirs:
            subdir = os.path.join(non_bag_root, dirname)

            # Do not add a BagIt directory to the regular directory total
            if subdir in bag_paths:
                continue

            non_bag_directory_total += (
                non_bag_directory_sizes.get(subdir, 0)
            )

        non_bag_directory_sizes[non_bag_root] = (
            non_bag_directory_total
        )

    for directory, size in sorted(non_bag_directory_sizes.items()):
        relative_directory = os.path.relpath(
            directory,
            dir_path
        )

        dir_ws.append([
            os.path.basename(dir_path),
            directory,
            relative_directory,
            size
        ])

    summary_ws.append([
        os.path.basename(dir_path),
        "Regular Directory",
        dir_path,
        "",
        None,
        None,
        "",
        non_bag_total_size,
        non_bag_file_count,
        "",
        None,
        None,
        "Not applicable"
    ])

    print(
        f"Regular directory total: "
        f"{non_bag_total_size:,} bytes"
    )

    print(
        f"Regular directory files: "
        f"{non_bag_file_count:,}"
    )

    # Process each BagIt bag separately
    for bag_path in bag_paths:
        process_bag_directory(bag_path)
    
process_collection(collection_path)      
    
# Format sheets
for ws in [summary_ws, dir_ws, file_ws]:
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    for cell in ws[1]:
        cell.font = Font(bold=True)

    for col in ws.columns:
        max_length = 0
        col_letter = get_column_letter(col[0].column)

        for cell in col:
            if cell.value is not None:
                max_length = max(max_length, len(str(cell.value)))

        ws.column_dimensions[col_letter].width = min(max_length + 2, 60)

# Format byte columns with commas
for ws in [summary_ws, dir_ws, file_ws]:
    for row in ws.iter_rows():
        for cell in row:
            if "Bytes" in str(ws.cell(row=1, column=cell.column).value):
                cell.number_format = '#,##0'
                
output_directory = os.path.dirname(output_xlsx)
os.makedirs(output_directory, exist_ok=True)
wb.save(output_xlsx)

isfile = os.path.isfile(output_xlsx)

print(f"is file: {isfile}")
print(f"Saved Excel report to: {output_xlsx}")
